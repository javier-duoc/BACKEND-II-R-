package com.petsalud.backendpetsalud.security;

// Archivo temporalmente desactivado para pruebas
public class UsuarioDetailsService {
    // Vacío intencionalmente
}