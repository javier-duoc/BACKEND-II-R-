package com.petsalud.backendpetsalud.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import static org.springframework.security.config.Customizer.withDefaults;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // Desactivamos CSRF para permitir pruebas POST desde Postman
                .csrf(csrf -> csrf.disable())
                
                .authorizeHttpRequests(auth -> auth
                        // 1. Rutas Públicas (siempre primero)
                        .requestMatchers("/api/usuarios/registro", "/api/login").permitAll()
                        
                        // 2. Rutas Privadas con Roles específicos
                        .requestMatchers("/api/admin/**").hasRole("ADMIN")
                        .requestMatchers("/api/usuarios/**").hasAnyRole("VETERINARIO", "ADMIN")
                        .requestMatchers("/api/veterinario/**").hasAnyRole("VETERINARIO", "ADMIN")
                        .requestMatchers("/api/citas/**").hasAnyRole("VETERINARIO", "ADMIN")
                        .requestMatchers("/api/expedientes/**").hasAnyRole("VETERINARIO", "ADMIN")
                        .requestMatchers("/api/mascotas/**").hasAnyRole("VETERINARIO", "ADMIN")
                        .requestMatchers("/api/notificaciones/**").hasAnyRole("VETERINARIO", "ADMIN")
                        .requestMatchers("/api/productos/**").hasAnyRole("VETERINARIO", "ADMIN")
                        .requestMatchers("/api/servicios/**").hasAnyRole("VETERINARIO", "ADMIN")
                        
                        // 3. Cualquier otra petición (SIEMPRE AL FINAL)
                        .anyRequest().authenticated()
                )
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                .httpBasic(withDefaults());

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder encoder) {
        UserDetails usuario = User.withUsername("cliente1")
                .password(encoder.encode("12345"))
                .roles("USER")
                .build();
    
        UserDetails administrador = User.withUsername("admin123")
                .password(encoder.encode("admin123")) // Ojo: La contraseña ahora es "admin123"
                .roles("ADMIN")
                .build();

        UserDetails veterinario = User.withUsername("veterinario")
                .password(encoder.encode("veterinario123"))
                .roles("VETERINARIO")
                .build();

        return new InMemoryUserDetailsManager(usuario, administrador, veterinario);
    }
}